﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Claims_Repository

{
    public enum GType
    {
        Car = 1 ,
        Home,
        Theft,
    }
    //proprety claim
    public class ClaimsContent
    {
        public int ClaimID { get; set; }
        public string Description { get; set; }
        public double ClaimAmount { get; set; }
        public DateTime DateOfIncident { get; set; }
        public DateTime DateofClaim { get; set; }
        public bool Isvalid { get; set; }
        public GType TypeG { get; set;  }

        public ClaimsContent() { }
        public ClaimsContent(int claimid, GType typec, string description, int claimamount, DateTime dateofincident, DateTime dateofclaim, bool isvalid)

        {
            ClaimID = claimid;
            Description = description;
            ClaimAmount = claimamount;
            DateOfIncident = dateofincident;
            DateofClaim = dateofclaim;
            Isvalid = isvalid;
            TypeG = typec;
            
        }

        
    }
}
