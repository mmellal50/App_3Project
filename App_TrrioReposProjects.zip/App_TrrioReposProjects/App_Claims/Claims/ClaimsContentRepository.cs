﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Claims_Repository
{
    public class ClaimsContentRepository
    {
        private List<ClaimsContent> _ListofContent = new List<ClaimsContent>();

        // create the claim list
        public void AddClaimTolist(ClaimsContent content)
        {
            _ListofContent.Add(content);
        }
        // rad 
        public List<ClaimsContent> GetContentList()
        {
            return _ListofContent;
        }
         //Delete
        public bool RemeoveContentFromList(int Name)
        {
            ClaimsContent content = GetContentByname(Name);
            if (content == null)
            {
                return false;
            }
            int initialcount = _ListofContent.Count;
            _ListofContent.Remove(content);
            if (initialcount > _ListofContent.Count)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //update
        public bool UpdateExistingContent(int originalName, ClaimsContent newcontent)
        {
            // look for content
            ClaimsContent oldcontent = GetContentByname(originalName);
            if (oldcontent != null)
            {
                oldcontent.ClaimID = newcontent.ClaimID;
                oldcontent.TypeG = newcontent.TypeG;
                oldcontent.Description = newcontent.Description;
                oldcontent.ClaimAmount = newcontent.ClaimAmount;
                oldcontent.DateOfIncident = newcontent.DateOfIncident;
                oldcontent.DateofClaim = newcontent.DateofClaim;
                oldcontent.Isvalid = newcontent.Isvalid;
                
                return true;
               
            }
            else
            {
                return false;
            }
        }

        // access method 
        public ClaimsContent GetContentByname(int ClaimID)
        {
            foreach (ClaimsContent content in _ListofContent)
            {
                if (content.ClaimID == 1)
                {
                    return content;
                }
            }
            return null;
        }
    }
}
