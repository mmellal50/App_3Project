﻿using Claims_Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Claims_Test
{
    [TestClass]
    public class ClaimContentTesta
    {
        [TestMethod]
        // exmaple test object of poco 
        public void TestTitle_SetStringCorrect()

        {
            ClaimsContent content = new ClaimsContent();
            content.ClaimID = 1;
            int setfortest = 1;
            int actualget = content.ClaimID;
            Assert.AreEqual(setfortest, actualget);
        }
    }
}
