﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Claims_Repository;

namespace Claims_Console
{
    

class ProgramUI
    {
        private List<ClaimsContent> _listClaim = new List<ClaimsContent>();
        
        public void Run()
        {
            Menu();
        }
        // Main Menu
        /*

        ClaimID	Type	Description	Amount	DateOfAccident	DateOfClaim	IsValid
        1	Car	Car accident on 465.	$400.00	4/25/18	4/27/18	true
        2	Home	House fire in kitchen.	$4000.00	4/11/18	4/12/18	true
        3	Theft	Stolen pancakes.	$4.00	4/27/18	6/01/18	false*/
        private void Menu()
        {
            int running = 3;
            while (running >= 0)
            {



                Console.WriteLine("choose a menu option :\n" +
                "1. See all Claims\n" +
                "2. Take care of next Claim\n" +
                "3. Enter a new Claim\n" +
                "4. this app have time countdow to exit. selct to initiate");

                // Get the user input
                string input = Console.ReadLine();

                //evaluate user input
                // time out set


                switch (input)
                {
                    case "1":

                        Newmen1();



                        break;
                        
                    case "2":

                        // take care of next claim just duplicat of three
                        Console.WriteLine("duplicate space to add in future go to  1 or 3 ");
                        Console.ReadLine();
                        break;
                    case "3":
                        // eneter a new clam
                        Nextmenu();

                        break;
                    case "4":
                        {
                            var seconds = running;// Convert.ToInt32(Console.ReadLine());
                            for (var i = seconds - 1; i <= seconds; i--)
                            {
                                Thread.Sleep(1000);
                                //  Console.Write("\rSeconds: " + i);
                                if (i == 0)
                                {

                                    //Console.Write("\rTime has done.");
                                    //Console.ReadLine();
                                    running = 0;
                                    Environment.Exit(0);

                                }
                            }

                            break;

                        }
                    default:
                        Console.WriteLine("please enter valid number");
                        break;
                }
            }

        }
      
        // create first menu display
        private void Newmen1()
        {
            List<ClaimsContent> Claim1 = new List<ClaimsContent>();


           Claim1.Add(new ClaimsContent());
            Claim1[0].ClaimID = 1; Claim1[0].TypeG = GType.Car; Claim1[0].Description = "Car accident on 465";
            Claim1[0].ClaimAmount = 400; Claim1[0].DateOfIncident = new DateTime(18, 4, 27);
            Claim1[0].DateOfIncident = new DateTime(18, 4, 27); Claim1[0].Isvalid = true;

            Claim1.Add(new ClaimsContent());
            Claim1[1].ClaimID = 2; Claim1[1].TypeG = GType.Home; Claim1[1].Description = "house in kitchen";
            Claim1[1].ClaimAmount = 4000; Claim1[1].DateOfIncident = new DateTime(18, 4, 11);
            Claim1[1].DateOfIncident = new DateTime(18, 4, 22); Claim1[1].Isvalid = true;

            Claim1.Add(new ClaimsContent());
            Claim1[2].ClaimID = 3; Claim1[2].TypeG = GType.Theft; Claim1[2].Description = "stolen pankacke";
            Claim1[2].ClaimAmount = 4; Claim1[2].DateOfIncident = new DateTime(18, 4, 27);
            Claim1[2].DateOfIncident = new DateTime(18, 6, 1); Claim1[2].Isvalid = false;

            foreach (ClaimsContent Clims01 in Claim1)

            {
                Console.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine(Clims01.ClaimID +"   " +Clims01.TypeG + "    "+Clims01.Description + "            "+Clims01.ClaimAmount + "      " +Clims01.DateOfIncident + "     " +Clims01.DateofClaim + "      " +Clims01.Isvalid + "  ");
                Console.WriteLine("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }
        }
        // enter new data   
        private void Nextmenu()

        {
            // ID
            ClaimsContent newContent = new ClaimsContent();
            Console.WriteLine(" eneter the claim ID :");
            newContent.ClaimID = Convert.ToInt32(Console.ReadLine());

            // type of claim 
            Console.WriteLine("enter the claim type  1:car 2:home 3:theft");
            int k = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("The type is {0}", Enum.GetName(typeof(GType), k));
            // description
            Console.WriteLine(" eneter claim description :");
            newContent.Description = Console.ReadLine();
            // Claim amount 
            Console.WriteLine("Amoun Damage");
            newContent.ClaimAmount = Convert.ToInt32(Console.ReadLine());
         
            //validate the claim

            ValiDate();
            


        }



       public void ValiDate()

       {
            ClaimsContent Claimvalidate = new ClaimsContent();
            Console.Write("Date of accident (e.g. 7/18/2021): ");
            DateTime date1 = DateTime.Parse(Console.ReadLine());
            Claimvalidate.DateofClaim = date1;

            Console.Write("Date of Claim : ");
            DateTime date2 = DateTime.Parse(Console.ReadLine());
            
            Claimvalidate.DateOfIncident = date2;
            int result = DateTime.Compare(date1, date2);
            

            if (result >0)
            {
                //Console.WriteLine("The variable is set to true.");
                Claimvalidate.Isvalid = false;
                Console.WriteLine("This claim is not valid please verify the information again");
                Console.ReadLine();
            }
            else 
            {
               // Console.WriteLine("The variable is set to false.");
                Claimvalidate.Isvalid = true;
                Console.WriteLine("This claim valid ");
                Console.ReadLine();
            }


        
        }
            
           
           

        }
}

