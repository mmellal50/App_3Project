﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace K_Repository_console
{
    class Startup
    {
        static void Main(string[] args)
        {
            ProgramUI Startup = new ProgramUI();
            Startup.Run();
        }
    }
}
