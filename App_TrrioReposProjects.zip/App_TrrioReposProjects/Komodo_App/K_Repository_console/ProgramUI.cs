﻿using KM_Repoaitory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace K_Repository_console
{
    class ProgramUI
    {
        readonly KomodoRepository  _newrepo = new KomodoRepository();
        public void Run()
        {
            refreshmemory();
            KomodoMenu();
        }
        private void KomodoMenu()

        {
            int running = 4;
            while (running <= 4)
            {


                //option
                
                
                Console.WriteLine("menu option:\n" +
                    "1.New Menu name\n" +
                    "2.Display the Menu\n" +
                    "3.Update Menu\n" +
                    "4.Delete Menu\n" +
                    "5.initiate the exit");
                // User acces
                string input = Console.ReadLine();
                //user choices
                switch (input)
                {
                    case "1":
                        CreateNewMenu();
                        break;
                    case "2":
                        DisplayAllMenu();
                        break;
                    case "3":
                        UpdateExistingMenue();
                        break;
                    case "4":
                        DeleteExistingMenu();
                        break;
                    case "5":
                        running = 5;
                        break;
                    default:
                        Console.WriteLine("nuber between 1 to 5");
                        break;
                }
                Console.WriteLine("please press any key to continue");
                Console.ReadKey();
                Console.Clear();
            }
        }
        // create new menu
        private void CreateNewMenu()
        {
          // new menu name
            Komodo newcontent = new Komodo();
            Console.WriteLine("eneter name of the menu");

            newcontent.Name = Console.ReadLine();
           

            //disciption
            Console.WriteLine("enter discription menu");
            newcontent.Discription = Console.ReadLine();
            
            //ingidient
            Console.WriteLine("enter ingidient");
            newcontent.Ingridient = Console.ReadLine();
         
            //number in menu
            Console.WriteLine("enter number");
            newcontent.Number = int.Parse(Console.ReadLine());

            // price in menu
            Console.WriteLine("enter Price");
            newcontent.Price = int.Parse(Console.ReadLine());
           
            //u[date the repo memory
            _newrepo.AddContentToList(newcontent);


        }
        // view repo memory
        private void DisplayAllMenu()
        {
            List<Komodo> LisofMenu = _newrepo.GetContentList();
            foreach (Komodo content in LisofMenu)
            {
                Console.WriteLine($"Menu : {content.Name}\n" +
                    $"Desc : {content.Discription}");
            }
        }
        //update existing Menu
        private void UpdateExistingMenue()
        {
            DisplayAllMenu();
            Console.WriteLine("enter new menu to update");
            string oldmenu = Console.ReadLine();

            // new menu name
            Komodo newcontent = new Komodo();
            Console.WriteLine("eneter name of the menu");

            newcontent.Name = Console.ReadLine();


            //disciption
            Console.WriteLine("enter discription menu");
            newcontent.Discription = Console.ReadLine();

            //ingidient
            Console.WriteLine("enter ingidient");
            newcontent.Ingridient = Console.ReadLine();

            //number in menu
            Console.WriteLine("enter number");
            newcontent.Number = int.Parse(Console.ReadLine());

            // price in menu
            Console.WriteLine("enter Price");
            newcontent.Price = int.Parse(Console.ReadLine());
            _newrepo.UpdateExistingContent(oldmenu, newcontent);
        }
        // remove Existing Menu
        private void DeleteExistingMenu()
        {
            DisplayAllMenu();
            Console.WriteLine("what menu to remove");

            string input = Console.ReadLine();

            bool deleted = _newrepo.RemeoveContentFromList(input);

        }
        private void refreshmemory()
        {
            Komodo newmenn = new Komodo();
            newmenn.Name = "Lazania";
            newmenn.Discription = "Italian cheese pizza";
            newmenn.Ingridient = "cheese beef tomatom ...";
            newmenn.Price = 10;
            newmenn.Number = 3;
            _newrepo.AddContentToList(newmenn);


        }
            
    }
}
