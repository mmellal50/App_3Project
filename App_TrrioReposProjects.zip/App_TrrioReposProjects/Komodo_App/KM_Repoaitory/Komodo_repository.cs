﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KM_Repoaitory
{ // crud, repository memory

    public class KomodoRepository
    {
        public List<Komodo> _KomodoList = new List<Komodo>();
        // create
        public void AddContentToList(Komodo content)
        {
            _KomodoList.Add(content);
        }
        // read
        public List<Komodo> GetContentList()
        {
            return _KomodoList;
        }




        //Delete
        public bool RemeoveContentFromList(string Name)
        {
            Komodo content = GetContentByname(Name);
            if (content == null)
            {
                return false;
            }
            int initialcount = _KomodoList.Count;
            _KomodoList.Remove(content);
            if (initialcount > _KomodoList.Count)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //update
        public bool UpdateExistingContent(string originalName, Komodo newcontent)
        {
            // look for content
            Komodo oldcontent = GetContentByname(originalName);
            if (oldcontent != null)
            {
                oldcontent.Name = newcontent.Name;
                oldcontent.Discription = newcontent.Discription;
                oldcontent.Ingridient = newcontent.Ingridient;
                oldcontent.Number = newcontent.Number;
                oldcontent.Price = newcontent.Price;
                return true;
            }
            else
            {
                return false;
            }
        }

        // access method 
        public Komodo GetContentByname(string Name)
        {
            foreach (Komodo content in _KomodoList)
            {
                if (content.Name == Name)
                {
                    return content;
                }
            }
            return null;
        }
    }
}
