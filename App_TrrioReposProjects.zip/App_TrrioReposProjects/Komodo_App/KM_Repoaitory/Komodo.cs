﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KM_Repoaitory
{ // poco structure

    public class Komodo
    {
        public string Name { get; set; }
        public string Discription { get; set; }
        public string Ingridient { get; set; }

        public int Number { get; set; }
        public int Price { get; set; }
        public Komodo() { }
        public Komodo(string name, string discription, string ingridient, int number, int price)
        {
            Name = name;
            Discription = discription;
            Ingridient = ingridient;
            Number = number;
            Price = price;
        }


    }
}
