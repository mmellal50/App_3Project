﻿using KM_Repoaitory;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace KN_Repository_test
{
    [TestClass]
    public class KomodTest
    {
        [TestMethod]
        public void Methodtest()
            // test Add method
        {
            Komodo Mmenu = new Komodo();
            Mmenu.Name = "Lazania";
            KomodoRepository repository = new KomodoRepository();
            repository.AddContentToList(Mmenu);
            Komodo namefrommenu = repository.GetContentByname("Lazania");
            Assert.IsNotNull(namefrommenu);

        }
    }
}
