﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Badge_Repoitory
{
    public class  Badge
    {
       public int BadgeID { get; set; }

       
        //  trying create master class and slave class
        //  one hold the numbers of Doors
        //  one hold the type of Doors
        //  it will be two dimension system
        public int NumberDoors {get; set; }
        
        public string NameBadge { get; set; }

        public Badge() { }
        public Badge(int badgeID, int door, string nameBage)

        {
            BadgeID = badgeID;
            NumberDoors = door;
            NameBadge = nameBage;
        }
    }
}