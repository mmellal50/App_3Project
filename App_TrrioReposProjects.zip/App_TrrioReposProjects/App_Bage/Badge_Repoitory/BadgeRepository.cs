﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Badge_Repoitory
{
    
   public  class BadgeRepository

    {
        private List<Badge> _ListofContent = new List<Badge>();
        Badge Nbadge = new Badge();
       
        Dictionary<int, Badge> dictionoryBadge = new Dictionary<int, Badge>();
        
        // Create 
        public void Addcontenttodictionory(Badge content)
        {
            //dictionoryBadge.Add(int, content);
            dictionoryBadge.Add(Nbadge.BadgeID, content);
        }
        // read dictionary content
        public Dictionary<int, Badge> GetKeyValuePairs()
        {
            return dictionoryBadge;
        }

        // update dictionary content BadgeID NameBadge NumberDoors
        public bool updatexistingcontent(string originalName, Badge newcontent)
        {
            // track content
            Badge oldcontent = getcontentbyname(originalName);
            // update 
            if (oldcontent != null)
            {
                oldcontent.BadgeID = newcontent.BadgeID;
                oldcontent.NameBadge = newcontent.NameBadge;
                oldcontent.NumberDoors = newcontent.NumberDoors;
                return true;

            }
            else
            {
                return false;
            }
        }
        // update doors on an existing badge
        

        // delete elemet from dictionary badge ID
        public bool RemoveContentFromDict(string name)
        {
            Badge content = getcontentbyname(name);
          
            if (content == null)
            {
                return false;
            }
            int initialcount = dictionoryBadge.Count;
            
            dictionoryBadge.Remove(content.BadgeID);
           
            if (initialcount > dictionoryBadge.Count)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
      



        // check method
        public Badge getcontentbyname(string name)
        {
            foreach (Badge content in dictionoryBadge.Values)
            {
                if(content.NameBadge == Nbadge.NameBadge)
                {
                    return content;
                }
            }
            return null;
        }
    }
}
