﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Badge_Repoitory
{
    class NumberDoors<T>
    {
        //list of door asociate to each badge
        public string Door {get; set;}
        public NumberDoors(string doors)
        {
            Door = doors;
        }
    }
}
