﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Badge_console
{
    class Program
    {
        static void Main(string[] args)
        {
            BadgeUI program = new BadgeUI();
            program.Run();
        }
    }
}
