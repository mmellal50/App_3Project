﻿using System;
using Badge_Repoitory;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Badge_console
{
    class BadgeUI
    {
        public void Run()
        {
            Menu();
        }
        //Menu
        private void Menu()
        {
            //main meu
   
                Console.WriteLine("1.Add a Badge:\n"+
                    "2.Edit a Badge:\n"+
                    "3.List all Badges");
            // get user input
                string input = Console.ReadLine();
           
            switch (input)
            {
                case "1":
                    AddBadge();
                    break;

             case "2":
                    break;

                case "3":
                    break;



                 

            }
          
        }
        private void AddBadge()
        {
            Badge Nbadge = new Badge();
            Nbadge.BadgeID = 12345;
            Console.WriteLine("what is the number on the badge"+Nbadge.BadgeID);
            Console.ReadKey();
            Nbadge.NumberDoors = 15;
            Console.WriteLine("list of doors(y/n)" + Nbadge.BadgeID);
            Console.ReadKey();

        } 
        // door acces clearance

        private void Dooracces()
        {
            Badge NeBadge = new Badge();
            Console.WriteLine("eneter badge number:");
            int mewnumber =Convert.ToInt32( Console.ReadLine());
            // access method
            checkclearance();

            if (mewnumber == numberacces)
            {
                Console.WriteLine("yes you have acces");
            }
            else
            {
                Console.WriteLine("no acces");
            }
        }
           // retreve acces number
           private void checkclearance()
        {
            Badge Nbadfe1 = new Badge();
            Console.WriteLine("eneter door acces for this type:");
            int numberacces =Convert.ToInt32(Console.ReadLine());
        }
    }
}
